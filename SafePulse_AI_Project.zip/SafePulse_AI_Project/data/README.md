This folder is reserved for sample or public traffic datasets added later.
The current prototype generates simulated records in code and does not require a dataset file.
If you add a public dataset, include its source URL, licence, date accessed, and any preprocessing steps here.
