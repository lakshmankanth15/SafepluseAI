"""Transparent, illustrative risk scoring for the SafePulse AI prototype."""

def assess_risk(row):
    score = 0
    reasons = []

    speed = float(row.get("avg_speed_kmh", 0))
    congestion = float(row.get("congestion_pct", 0))
    visibility = float(row.get("visibility_m", 10000))
    vehicles = int(row.get("vehicle_count", 0))

    # Illustrative thresholds only; not validated for real-world use.
    if speed >= 80:
        score += 35
        reasons.append("high average speed")
    elif speed >= 60:
        score += 20
        reasons.append("elevated average speed")

    if congestion >= 80:
        score += 25
        reasons.append("heavy congestion")
    elif congestion >= 55:
        score += 15
        reasons.append("moderate-to-heavy congestion")

    if visibility < 100:
        score += 35
        reasons.append("very poor visibility")
    elif visibility < 300:
        score += 20
        reasons.append("reduced visibility")

    if vehicles >= 80:
        score += 10
        reasons.append("high vehicle volume")

    score = min(score, 100)
    if score >= 55:
        level = "HIGH"
        action = "Request operator verification and follow local traffic protocols."
    elif score >= 25:
        level = "MEDIUM"
        action = "Review conditions and monitor for deterioration."
    else:
        level = "LOW"
        action = "Continue routine monitoring."

    if not reasons:
        reasons = ["no configured risk trigger detected"]

    return score, level, "; ".join(reasons), action
