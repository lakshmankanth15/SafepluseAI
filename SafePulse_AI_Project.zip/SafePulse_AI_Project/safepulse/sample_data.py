"""Generate clearly simulated traffic records for demonstration."""
from datetime import datetime, timedelta
import random

LOCATIONS = ["North Junction", "Market Road", "College Circle", "River Bridge", "Central Avenue"]

def make_sample_data(n=30, seed=None):
    rng = random.Random(seed)
    now = datetime.now().replace(microsecond=0)
    records = []
    for i in range(n):
        # Mix routine and challenging scenarios so the demo displays different risk levels.
        scenario = i % 5
        if scenario == 0:
            speed, congestion, visibility = rng.randint(82, 105), rng.randint(65, 95), rng.randint(50, 250)
        elif scenario == 1:
            speed, congestion, visibility = rng.randint(45, 72), rng.randint(58, 78), rng.randint(250, 900)
        else:
            speed, congestion, visibility = rng.randint(20, 58), rng.randint(10, 50), rng.randint(500, 3000)
        records.append({
            "timestamp": (now - timedelta(minutes=(n-i)*2)).strftime("%Y-%m-%d %H:%M:%S"),
            "location": rng.choice(LOCATIONS),
            "vehicle_count": rng.randint(5, 100),
            "avg_speed_kmh": speed,
            "congestion_pct": congestion,
            "visibility_m": visibility,
            "data_source": "SIMULATED"
        })
    return records_to_frame(records)

def records_to_frame(records):
    import pandas as pd
    return pd.DataFrame(records)
