import streamlit as st
import pandas as pd
from safepulse.risk_engine import assess_risk
from safepulse.sample_data import make_sample_data

st.set_page_config(page_title="SafePulse AI", page_icon="🚦", layout="wide")

st.title("🚦 SafePulse AI")
st.caption("Prototype • Real-time road-risk decision support • Demo data only")

with st.sidebar:
    st.header("Demo controls")
    st.write("This prototype uses simulated traffic records. It is not connected to live cameras or sensors.")
    row_count = st.slider("Number of simulated records", min_value=10, max_value=100, value=30, step=10)
    if st.button("Generate new demo data"):
        st.session_state["traffic_data"] = make_sample_data(row_count)
    st.divider()
    st.markdown("**Risk rule inputs**")
    st.caption("Rules are illustrative and must be calibrated with validated local data before real use.")

if "traffic_data" not in st.session_state:
    st.session_state["traffic_data"] = make_sample_data(row_count)

data = st.session_state["traffic_data"].copy()
results = data.apply(assess_risk, axis=1, result_type="expand")
data[["risk_score", "risk_level", "reasons", "recommended_action"]] = results

c1, c2, c3, c4 = st.columns(4)
c1.metric("Records analysed", len(data))
c2.metric("High risk", int((data["risk_level"] == "HIGH").sum()))
c3.metric("Medium risk", int((data["risk_level"] == "MEDIUM").sum()))
c4.metric("Low risk", int((data["risk_level"] == "LOW").sum()))

st.subheader("Traffic risk overview")
chart_data = data[["timestamp", "risk_score"]].set_index("timestamp")
st.line_chart(chart_data)

st.subheader("Risk alerts")
def highlight_risk(row):
    if row["risk_level"] == "HIGH":
        return ["background-color: #ffe0e0; color: #5b1010"] * len(row)
    if row["risk_level"] == "MEDIUM":
        return ["background-color: #fff1cc; color: #5a3b00"] * len(row)
    return ["background-color: #e0f5e8; color: #104b2b"] * len(row)

display_cols = [
    "timestamp", "location", "vehicle_count", "avg_speed_kmh",
    "congestion_pct", "visibility_m", "risk_score", "risk_level",
    "reasons", "recommended_action"
]
st.dataframe(data[display_cols].style.apply(highlight_risk, axis=1), use_container_width=True, hide_index=True)

csv_bytes = data.to_csv(index=False).encode("utf-8")
st.download_button("Download analysed records (CSV)", data=csv_bytes,
                   file_name="safepulse_analysed_traffic.csv", mime="text/csv")

with st.expander("About this prototype"):
    st.markdown("""
    - **Inputs:** simulated vehicle count, average speed, congestion and visibility.
    - **Risk engine:** transparent rule-based score for demonstration.
    - **Outputs:** risk category, contributing factors and a suggested operator action.
    - **Safety:** alerts are advisory only. Do not use this prototype for real traffic control.
    - **IBM LinuxONE:** enterprise deployment is a proposed next step, not an implemented integration.
    """)
