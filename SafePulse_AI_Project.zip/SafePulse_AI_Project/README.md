# SafePulse AI

**Real-Time Road Risk Detection & Early Warning — prototype**

SafePulse AI is a small Streamlit prototype that demonstrates how traffic indicators can be transformed into transparent, rule-based risk alerts. It uses simulated traffic data and is intended for a hackathon demonstration, not real-world traffic control.

## Features

- Simulated traffic records for five demo locations
- Illustrative risk score based on average speed, congestion, visibility, and vehicle volume
- Low / Medium / High risk categories
- Explanation of contributing factors and a suggested operator action
- Trend chart, alert table, and CSV download
- Clear labelling that demo records are simulated

## Run locally

1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Create and activate a virtual environment (recommended).
5. Install dependencies and run:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

Streamlit will print a local URL, usually `http://localhost:8501`.

## Project structure

```text
SafePulse_AI_Project/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── README.md
└── safepulse/
    ├── __init__.py
    ├── risk_engine.py
    └── sample_data.py
```

## Risk score (illustrative)

- Average speed >= 80 km/h: +35
- Average speed >= 60 km/h: +20
- Congestion >= 80%: +25
- Congestion >= 55%: +15
- Visibility < 100 m: +35
- Visibility < 300 m: +20
- Vehicle count >= 80: +10

The score is capped at 100. Scores >= 55 are High, >= 25 are Medium, otherwise Low. These thresholds are illustrative, not validated traffic-safety standards.

## IBM Z / LinuxONE integration plan

The current version runs in a standard Python environment and **does not yet run on IBM Z or LinuxONE**. A future deployment could package the app and processing service in containers and host them on an IBM LinuxONE Linux environment. Security controls, access management, encryption, observability, and performance must be configured and tested as part of that integration.

## Limitations and responsible use

- All generated records are simulated; no live sensor or camera feed is connected.
- The scoring rules are not a validated predictive model.
- Do not use this prototype to direct traffic or make emergency decisions.
- Real deployment would require validated datasets, local expert review, privacy assessment, field testing, and measured evaluation.

## Open-source tools

- Python: https://www.python.org/
- Streamlit: https://streamlit.io/
- Pandas: https://pandas.pydata.org/

## Suggested next improvements

1. Add a validated public traffic dataset and document its licence/source.
2. Add tests for risk-engine thresholds and malformed inputs.
3. Evaluate alert correctness and processing latency.
4. Add user authentication and audit logging before any sensitive deployment.
5. Complete and verify IBM LinuxONE deployment before claiming it is implemented.
